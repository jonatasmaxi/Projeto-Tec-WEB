<?php
/* 
 * Tela de ajuda, politica de privacidade
 */
