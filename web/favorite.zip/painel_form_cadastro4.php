<?php include 'connector_mysql.php'?>
<?php include 'header.php'?>
    <section>
        <div class="content-full">
            <h1>
                Cadastro Realizado com Sucesso <br> <br>
            </h1>
            <a href="index.php"> Retornar à página principal </a>
        </div>
    </section>
<?php include 'footer.php'?>
