<?php include 'header.php' ?>
<head>
    <section>   
        <h1> Paínel do Usuário </h1>
        <ul class="painelusuario">
            <li> <a href="meusuploads.php"> Meus Uploads </a> </li>
            <li> <a href="cadastro.php"> Meu Cadastro </a> </li>
            <li> <a href="favorite.php"> Minha lista de desejos </a> </li>
        </ul>
    </section>
<?php include 'footer.php'?>

