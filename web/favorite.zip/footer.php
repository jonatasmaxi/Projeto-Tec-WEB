<footer id="footerSite">
            <div class="copyright">
                Copyright Coink © 2015
            </div>    
            <nav class="menuFooter">
                <ul>
                    <li>Política de privacidade</li>
                    <li>Mapa do site</li>
                    <li>Quem somos</li>
                    <li>Contato</li>
                    <li>Ajuda</li>
                </ul>
            </nav>
        </footer>
        </div>
    </body>
</html>
