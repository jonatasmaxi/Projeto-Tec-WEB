<?php include 'connector_mysql.php'?>
<?php include 'header.php'?>
<section>
    <div class="content-full">
        <form>
            <label>Login</label><br>
            <input type="text"/>
            <br><br>
            <label>Password</label><br>
            <input type="text"/>
        </form>
    </div>
</section>
<?php include 'footer.php'?>