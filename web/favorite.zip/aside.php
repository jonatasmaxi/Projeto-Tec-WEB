<aside>
    <nav class="menuDepartments">
        <ul class="egmenu">
            <li><a href="#">Games</a>
                <ul>
                    <li><a href="#" class="has-sub">Xbox One</a>
                        <ul>
                            <li>Acessórios</li>
                            <li>Jogos</li>
                        </ul>
                    </li>
                    <li><a href="#" class="has-sub">Xbox 360</a>
                        <ul>
                            <li>Acessórios</li>
                            <li>Jogos</li>
                        </ul>
                    </li>
                    <li><a href="#" class="has-sub">PlayStation 4</a>
                        <ul>
                            <li>Acessórios</li>
                            <li>Jogos</li>
                        </ul>
                    </li>
                    <li><a href="#" class="has-sub">PlayStation 3</a>
                        <ul>
                            <li>Acessórios</li>
                            <li>Jogos</li>
                            <li>Coisa</li>
                        </ul>
                    </li>
                    <li><a href="#" class="has-sub">Nintendo Wii U</a>
                        <ul>
                            <li>Acessórios</li>
                            <li>Jogos</li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li><a href="#" class="has-sub">Portáteis</a>
                <ul>
                    <li>Celulares e Smartphones</li>
                    <li>Tablets</li>
                    <li>Wearables</li>
                </ul>
            </li>
            <li><a href="#" class="has-sub">TVs, Áudio e Eletrônicos</a>
                <ul>
                    <li>TVs</li>
                    <li>Home Theaters</li>
                    <li>Fones de Ouvido</li>
                    <li>Blu-Ray/DVD Players</li>
                    <li>GPS</li>
                </ul>
            </li>
            <li><a href="#" class="has-sub">Informática</a>
                <ul>
                    <li>Notebooks</li>
                    <li>Computadores</li>
                    <li>Multifuncionais e Impressoras</li>
                    <li>GPS</li>
                    <li><a href="#" class="has-sub">Acessórios de Informática</a>
                        <ul>
                            <li>Cartões de memória</li>
                            <li>Pendrives</li>
                            <li>HDs Externo</li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>
</aside>