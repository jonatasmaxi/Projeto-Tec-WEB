<?php 
			mysql_connect('localhost', 'ckodecom_coink', 'Ckode167!');
			mysql_select_db('ckodecom_coink') or die(mysql_error());
?>