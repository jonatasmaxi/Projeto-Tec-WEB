<?php include 'connector_mysql.php'?>
<?php include 'header.php'?>
<section>
    <?php include 'aside.php'?>
    <div class="content">
        <!-- Se o usuário estiver logado -->
        Interface da lista de desejo
        
        <!-- Se o usuário não estiver logado -->
        <p>Faça login e crie sua lista de desejos</p>
    </div>
</section>
<?php include 'footer.php'?>